const express = require('express');
const router = express.Router();
const fs = require("fs");
const path = require("path");

const quizle = "./model/quizle.json";

const userDBFileName = "./model/userDB.json";

function readQuizle() {
    let data = fs.readFileSync(quizle, "utf-8");
    return JSON.parse(data);
}

function readUserDB() {
    let data = fs.readFileSync(userDBFileName, "utf-8");
    return JSON.parse(data);


}

function writeUserDB(users){
    let data = JSON.stringify(users, null, 2);
    fs.writeFileSync(userDBFileName, data, "utf-8");
    //make this so that users who type in login credentials that dont match are taken into sign up page
    
}



router.get('/', (req, res) => {
    res.sendFile("/home/timothyng0169/csci355/Summer/csci355proj2/index.html")
  })


  
router.post('/login-form', (req, res) => {
    const quizData = readQuizle();

    const shuffledQuestions = [...quizData].sort(() => Math.random() - 0.5);
    const selectedQuestions = shuffledQuestions.slice(0, 10);
    res.render('quiz', { questions: selectedQuestions });
    console.log(selectedQuestions);
    let userDB = readUserDB();
    userDB.push({ questions: selectedQuestions });
    writeUserDB(userDB);
  })


router.get('/quiz', (req, res) => {
    console.log("User request for quiz page");

    const quizData = readQuizle();

    const shuffledQuestions = [...quizData].sort(() => Math.random() - 0.5);
    const selectedQuestions = shuffledQuestions.slice(0, 10);
    res.render('quiz', { questions: selectedQuestions });
    console.log(selectedQuestions);
    let userDB = readUserDB();
    userDB.push({ questions: selectedQuestions });
    writeUserDB(userDB);
});

router.post('/submit-quiz', (req, res) => {
    const userAnswers = req.body;
    console.log("User submitted answers:", userAnswers);
    let scorecount = 0;
    let userDB = readUserDB();
    const lastQuiz = userDB[userDB.length - 1];
    const questions = lastQuiz.questions;

    
    questions.forEach((question, index) => {
        const userAnswer = userAnswers[`question${index}`]; // User's answer
        const correctAnswer = question.answer; // Correct answer from quizle.json

        if (userAnswer === correctAnswer) {
            scorecount++;
        }
    });

    console.log(`User scored ${scorecount}/${questions.length}`);
    res.render('result', { score: scorecount });
    // res.send(`You scored ${scorecount}/${questions.length}`);
})


router.post('/home-redirect', (req, res) => {
    res.sendFile("/home/timothyng0169/csci355/Summer/csci355proj2/index.html");
})

module.exports = router;

